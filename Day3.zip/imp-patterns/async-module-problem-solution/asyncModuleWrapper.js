"use strict";

const asyncModule = require('./asyncModule');

//The wrapper - Proxy
const asyncModuleWrapper = module.exports;
asyncModuleWrapper.initialized = false;

asyncModuleWrapper.initialize = function() {
  //Invoke Initialize On ActiveState
  activeState.initialize.apply(activeState, arguments);
};

asyncModuleWrapper.doSomething = function() {
  activeState.doSomething.apply(activeState, arguments);
};

//The state to use when the module is not yet initialized
let pending = [];

let notInitializedState = {

  initialize: function(callback) {
    //trigger the initialization of the original asyncModule module, providing a callback proxy
    asyncModule.initialize(function() {

      asyncModuleWrapper.initalized = true;
      activeState = initializedState;//Updates the activeState variable with the next state object in our flow—initializedState
      //Executes all the commands that were previously stored in the pending queue
      pending.forEach(function(req) {
        asyncModule[req.method].apply(null, req.args);
      });
      pending = [];
      //Invoke Original Callback
      callback();
    });
  },
  
  doSomething: function(callback) {
    //creates a new Command object and adds it to the queue of the pending operations.

    return pending.push({
      method: 'doSomething',
      args: arguments
    });
  }
  
};

//The state to use when the module is initialized
let initializedState = asyncModule;


//Set the initial state to the notInitializedState
let activeState = notInitializedState;

