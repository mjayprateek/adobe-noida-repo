"use strict";

const asyncModuleProxy = require('./asyncModuleWrapper');

module.exports.handleDefaultRoute = (req, res) => {
  asyncModuleProxy.doSomething((err, something) => {
    if(err) {
      res.writeHead(500);
      return res.end('Error:' + err.message);
    }
    res.writeHead(200);
    res.end('I say: ' + something);
  });
};
