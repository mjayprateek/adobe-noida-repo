

"use strict";

// const level = require('level');
// const sublevel = require('level-sublevel');

// const db = sublevel(level('example-db', {valueEncoding: 'json'}));
// const salesDb = db.sublevel('sales');

module.exports = function totalSales(item, callback) {
  console.log('totalSales() invoked');
  
 setTimeout(() => {
   
  callback(null,1000);
 }, 5000);
};
