"use strict";

const totalSales = require('./totalSales');

const queues = {};
module.exports = function totalSalesBatch(item, callback) {
  if(queues[item]) {  // [1]
    console.log('Batching operation');
    return queues[item].push(callback);
  }
  
  queues[item] = [callback];  // [2]
  totalSales(item, (err, res) => {
    const queue = queues[item];  // [3]
    queues[item] = null;
    queue.forEach(cb => cb(err, res));
  });
};

/*
1.If a queue already exists for the item type provided as the input, it means that a request for that particular item is already running. In this case, all we have to do is simply append the callback to the existing queue and return from the invocation immediately. Nothing else is required
2.If no queue is defined for the item, it means that we have to create a new request. To do this, we create a new queue for that particular item and we initialize it with the current callback function. Next, we invoke the original totalSales() API
3.When the original totalSales() request completes, we iterate over all the callbacks that were added in the queue for that specific item and invoke them one by one with the result of the operation.
*/