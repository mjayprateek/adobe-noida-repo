"use strict";

const pify = require('pify');  // [1]
const totalSales = pify(require('./totalSales'));

const cache = {};
module.exports = function totalSalesPromises(item) {
  if (cache[item]) {  // [2]
    return cache[item];
  }

  cache[item] = totalSales(item)  // [3]
    .then(res => {  // [4]
      setTimeout(() => {delete cache[item]}, 30 * 1000); //30 seconds expiry
      return res;
    })
    .catch(err => {  // [5]
      delete cache[item];
      throw err;
    });
  return cache[item];  // [6]
};


/*
1.pify (https://www.npmjs.com/package/pify)  allows us to apply a promisification to the original totalSales(). After doing this, totalSales() will return a ES2015 promise instead of accepting a callback
2.When the totalSalesPromises() wrapper is invoked, we check whether a cached promise already exists for the given item type. If we already have such a promise, we return it back to the caller.
3.If we don't have a promise in the cache for the given item type, we proceed to create one by invoking the original (promisified) totalSales() API.
4.When the promise resolves, we set up a time to clear the cache (after 30 seconds) and we return res to propagate the result of the operation to any other then() listener attached to the promise.
5.If the promise rejects with an error, we immediately reset the cache and throw the error again to propagate it to the promise chain, so any other listener attached to the same promise will receive the error as well.
6.At last, we return the cached promise we just created.


*/