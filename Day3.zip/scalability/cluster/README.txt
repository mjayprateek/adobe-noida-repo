This sample demonstrates how to scale a Node.js application using the cluster module

To try the sample simply run:
  node clusteredApp
