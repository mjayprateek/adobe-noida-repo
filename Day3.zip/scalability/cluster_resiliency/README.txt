This sample demonstrates how a cluster of Node.js processes
can maintain a high availability even in presence of crashes.

To try the sample simply run:
  node clusteredApp
