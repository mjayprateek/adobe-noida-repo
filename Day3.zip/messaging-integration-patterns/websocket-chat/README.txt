This sample demonstrates how to implement a basic chat application in Node.js

To try the sample first install the dependencies:
  npm install

Then run:
  node app
  
To access the application open a browser at the address:
  http://localhost:8080
