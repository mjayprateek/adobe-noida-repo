This is an example of a simple web spider.
To run this example you need to:

1. install the dependencies with:
     npm install

2. download a website of your choice with
     node index.js <url of the website to download>
