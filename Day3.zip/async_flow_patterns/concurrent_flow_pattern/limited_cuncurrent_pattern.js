const tasks = [];
let concurrency = 2, running = 0, completed = 0, index = 0; 
function next() {                                             //[1] 
  while(running < concurrency && index < tasks.length) { 
    task = tasks[index++]; 
    task(() => {                                              //[2] 
      if(completed === tasks.length) { 
        return finish(); 
      } 
      completed++, running--; 
      next(); 
    }); 
    running++; 
  } 
} 
next(); 
 
function finish() { 
  //all tasks finished 
} 

/* Comments

1.We have an iterator function, which we called next(), and then an inner loop that spawns in parallel as many tasks as possible while staying within the concurrency limit.
2.The next important part is the callback we pass to each task, which checks if we completed all the tasks in the list. If there are still tasks to run, it invokes next() to spawn another bunch of tasks.

*/
